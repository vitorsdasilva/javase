
package br.com.cursojavaseudemy.desenvolvimentoemcamadas;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

/**
 *
 * @author e333832
 */
public class AutorDAO {
    
    public void adicionar(AutorModel objAutorModel){
        /* conectando ao banco de dados */
        Connection con = new Conexao().getConexao();
        
        /* Objeto para executar comando sql */
        PreparedStatement ps;
        String sql = "insert into Autor values (?,?,?)";
        
        try{
            
            ps = con.prepareStatement(sql);
            ps.setInt(1, objAutorModel.getCodigo());
            ps.setString(2, objAutorModel.getNome());
            ps.setString(3,objAutorModel.getEstado());
            
            ps.executeUpdate();
            
            JOptionPane.showMessageDialog(null, "Pronto para execucao de comando sql");
        }catch(SQLException sqle){
            JOptionPane.showMessageDialog(null,"Erro no acesso ao banco de dados" 
                                                + sqle.getMessage());
        }
        
        /* Fechando a conexao */
        try{
            con.close();
            JOptionPane.showMessageDialog(null, "Conexao com o banco foi fechada com sucesso");
        }catch(SQLException sqle){
            JOptionPane.showMessageDialog(null, "Erro ao fechar conexao com o banco de dados" 
                                                + sqle.getMessage());
        }
     
    }
    
    public AutorModel consultar(int codigo){
        
        Connection con = new Conexao().getConexao();
        AutorModel obj = new AutorModel();
        
        /* Objeto para executar comando sql */
        PreparedStatement ps;
        String sql = "select * from Autor where codigo = "+ codigo;
        
        try{
            ps = con.prepareStatement(sql);           
            ResultSet rs = ps.executeQuery();  
                rs.next();              
                obj.setCodigo(Integer.valueOf(rs.getString("codigo")));
                obj.setNome(rs.getString("nome"));
                obj.setEstado(rs.getString("estado"));
            
            ps.close();
            
        }catch(SQLException sqle){
            JOptionPane.showMessageDialog(null,"Erro no acesso ao banco de dados" 
                                                + sqle.getMessage());
            
        }
        
        /* Fechando a conexao */
        try{
            con.close();
            JOptionPane.showMessageDialog(null, "Conexao com o banco foi fechada com sucesso");
        }catch(SQLException sqle){
            JOptionPane.showMessageDialog(null, "Erro ao fechar conexao com o banco de dados" 
                                                + sqle.getMessage());
        }
       
        JOptionPane.showMessageDialog(null, "codigo: "+ obj.getCodigo()+ "nome: " + obj.getNome() +"estado: " + obj.getEstado());
        
        return obj;  
    }

    //retornar uma lista de autores
    public ArrayList<AutorModel> listarAutores() {
        
        
        Connection con = new Conexao().getConexao();
        PreparedStatement ps;
        String sql = "select * from Autor";
        ArrayList listaAutor = new ArrayList<AutorModel>();
        try{
            
            ps = con.prepareStatement(sql);           
            ResultSet rs = ps.executeQuery(); 
            AutorModel obj = new AutorModel();
            
            while(rs.next()){
                obj.setCodigo(Integer.valueOf(rs.getString("codigo")));
                obj.setNome(rs.getString("nome"));
                obj.setEstado(rs.getString("estado"));
                
                listaAutor.add(obj);
                
            }    
            ps.close();
            
            
        }catch(SQLException sqle){
            System.out.println(sqle.getMessage());
        }
        
        try{
            con.close();
            JOptionPane.showMessageDialog(null, "Conexao com o banco foi fechada com sucesso");
        }catch(SQLException sqle){
            JOptionPane.showMessageDialog(null, "Erro ao fechar conexao com o banco de dados"+sqle.getMessage());
        }
        
        return listaAutor;
    }
}