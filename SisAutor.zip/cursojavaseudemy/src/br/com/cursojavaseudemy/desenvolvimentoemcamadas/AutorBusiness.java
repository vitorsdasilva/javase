
package br.com.cursojavaseudemy.desenvolvimentoemcamadas;

import java.util.ArrayList;

/**
 *
 * @author e333832
 */
public class AutorBusiness {
    
    AutorDAO objAutorDAO;
    AutorView objAutorView;
    
    public AutorBusiness(){
        objAutorDAO = new AutorDAO();
    }
    
    /*
        validarDados verifica se o usuario preecheu todos os campos nao nulos.
    */
    
    private void validarDados(AutorModel objAutorModel) throws Exception{
        
        if(objAutorModel.getNome()==null || objAutorModel.getNome().equals("")){
           throw new Exception ("O campo nome e obrigatorio");
        }
    }
    
    public void adicionarAutor(AutorModel objAutorModel) throws Exception{
        validarDados(objAutorModel);
        objAutorDAO.adicionar(objAutorModel);
    }
    
        
    public Boolean consultarAutor(AutorModel objAutorModel){
        
        AutorModel objAutorModel2= new AutorModel();
        
        int codigo = objAutorModel.getCodigo();
        String nome = objAutorModel.getNome();
        String estado = objAutorModel.getEstado();
        objAutorModel2 = objAutorDAO.consultar(codigo);
        
        if (codigo == objAutorModel2.getCodigo()){
            return true;
        }
        
        return false;
    }
 
    public AutorModel buscarAutor(int codigo){
        
        AutorModel objAutorModel2;
        
       
        objAutorModel2 = objAutorDAO.consultar(codigo);
        
        if (codigo == objAutorModel2.getCodigo()){
            
            return objAutorModel2;
        }
     
        System.out.println("Autor nao cadastrado!");
        return null;
      
    }

    
}
