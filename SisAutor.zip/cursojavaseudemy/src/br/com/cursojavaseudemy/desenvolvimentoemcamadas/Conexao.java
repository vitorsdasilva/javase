/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.cursojavaseudemy.desenvolvimentoemcamadas;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author vitor
 */
public class Conexao {
     String urlDriverBD="org.apache.derby.jdbc.ClientDriver";
     String nomeBD="bdautor";
     String urlBD= "jdbc:derby://localhost:1527/"+nomeBD;
     String usuario = "vitor"; 
     String senha = "123456";
    
     public Connection getConexao(){
       
        try{
            Class.forName(urlDriverBD);
            JOptionPane.showMessageDialog(null, "Driver JDBC carregado");   
        }catch(ClassNotFoundException cnfe){
            JOptionPane.showMessageDialog(null, cnfe.getMessage());
        }
       
        /* Conectando ao banco de dados */
        try{
            System.out.println("Conectando...");
            return DriverManager.getConnection(urlBD,usuario,senha);
           
        }catch(SQLException sqle){
            System.out.println(sqle.getMessage());
            return null;
        }
    } 
  
}

